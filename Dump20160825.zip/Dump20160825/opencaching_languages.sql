-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `short` char(2) NOT NULL,
  `name` varchar(60) NOT NULL,
  `trans_id` int(10) unsigned NOT NULL,
  `native_name` varchar(60) NOT NULL,
  `de` varchar(60) NOT NULL COMMENT 'obsolete',
  `en` varchar(60) NOT NULL COMMENT 'obsolete',
  `list_default_de` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'obsolete',
  `list_default_en` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'obsolete',
  PRIMARY KEY (`short`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='static content';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES ('BG','Bulgarian',146,'български език','Bulgarisch','Bulgarian',0,0),('CA','Catalan',2243,'Català','Katalanisch','Catalan',0,0),('CS','Czech',145,'Čeština','Tschechisch','Czech',0,0),('DA','Danish',104,'Dansk','Dänisch','Danish',1,1),('DE','German',160,'Deutsch','Deutsch','German',1,1),('EL','Greek',103,'Ελληνικά','Griechisch','Greek',0,0),('EN','English',159,'English','Englisch','English',1,1),('EO','Esperanto',102,'Esperanto','Esperanto','Esperanto',0,0),('ES','Spanish',157,'Español','Spanisch','Spanish',1,1),('ET','Estonian',101,'Eesti','Estnisch','Estonian',0,0),('EU','Basque',100,'Euskara','Baskisch','Basque',0,0),('FI','Finnish',93,'Suomi','Finnisch','Finnish',0,0),('FR','French',158,'Français','Französisch','French',1,1),('HR','Croatian',92,'Hrvatski','Kroatisch','Croatian',0,0),('HU','Hungarian',91,'Magyar','Ungarisch','Hungarian',0,0),('IS','Icelandic',79,'Íslenska','Isländisch','Icelandic',0,0),('IT','Italian',78,'Italiano','Italienisch','Italian',0,0),('JA','Japanese',156,'日本語','Japanisch','Japanese',0,0),('LB','Luxembourgish',2242,'Lëtzebuergesch','Luxemburgisch','Luxembourgish',0,0),('LT','Lithuanian',77,'Lietuvių','Litauisch','Lithuanian',0,0),('LV','Latvian',76,'Latviešu','Lettisch','Latvian',0,0),('NL','Dutch',155,'Nederlands','Niederländisch','Dutch',1,1),('NO','Norwegian',75,'Norsk','Norwegisch','Norwegian',0,0),('PL','Polish',74,'Polski','Polnisch','Polish',1,1),('PT','Portuguese',64,'Português','Portugiesisch','Portuguese',0,0),('RO','Romanian',59,'Română','Rumänisch','Romanian',0,0),('RU','Russian',49,'Русский','Russisch','Russian',0,0),('SK','Slovak',48,'Slovenčina','Slowakisch','Slovak',0,0),('SL','Slovenian',43,'Slovenščina','Slowenisch','Slovenian',0,0),('SV','Swedish',42,'Svenska','Schwedisch','Swedish',0,0),('TH','Thai',2241,'ไทย','Thai','Thai',0,0),('TR','Turkish',36,'Türkçe','Türkisch','Turkish',0,0),('VI','Vietnamese',21,'Việt Nam','Vietnamesisch','Vietnamese',0,0),('ZH','Chinese',2240,'中文','Chinesisch','Chinese',0,0);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:49
