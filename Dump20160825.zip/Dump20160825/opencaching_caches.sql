-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caches`
--

DROP TABLE IF EXISTS `caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caches` (
  `cache_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `node` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL COMMENT 'via Trigger (caches)',
  `is_publishdate` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 = date_created is publication date',
  `last_modified` datetime NOT NULL COMMENT 'via Trigger (caches)',
  `listing_last_modified` datetime NOT NULL COMMENT 'via Trigger (caches, cache_desc, coordinates, pictures)',
  `meta_last_modified` datetime NOT NULL COMMENT 'via Trigger (stat_caches, gk_item_waypoint)',
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `longitude` double NOT NULL,
  `latitude` double NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `date_hidden` date NOT NULL,
  `size` tinyint(3) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL,
  `terrain` tinyint(3) unsigned NOT NULL,
  `logpw` varchar(20) DEFAULT NULL,
  `search_time` float unsigned NOT NULL DEFAULT '0',
  `way_length` float unsigned NOT NULL DEFAULT '0',
  `wp_gc` varchar(7) NOT NULL,
  `wp_gc_maintained` varchar(7) NOT NULL,
  `wp_nc` varchar(6) NOT NULL COMMENT 'obsolete',
  `wp_oc` varchar(7) NOT NULL,
  `desc_languages` varchar(60) NOT NULL COMMENT 'via Trigger (cache_desc)',
  `default_desclang` char(2) NOT NULL,
  `date_activate` datetime DEFAULT NULL,
  `need_npa_recalc` tinyint(1) NOT NULL,
  `show_cachelists` tinyint(1) NOT NULL DEFAULT '1',
  `protect_old_coords` tinyint(1) NOT NULL DEFAULT '0',
  `needs_maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `listing_outdated` tinyint(1) NOT NULL DEFAULT '0',
  `flags_last_modified` datetime NOT NULL COMMENT 'via Trigger (caches)',
  PRIMARY KEY (`cache_id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `wp_oc` (`wp_oc`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `date_created` (`date_created`),
  KEY `latitude` (`latitude`),
  KEY `country` (`country`),
  KEY `status` (`status`,`date_activate`),
  KEY `last_modified` (`last_modified`),
  KEY `wp_gc` (`wp_gc`),
  KEY `user_id` (`user_id`),
  KEY `date_activate` (`date_activate`),
  KEY `need_npa_recalc` (`need_npa_recalc`),
  KEY `type` (`type`),
  KEY `size` (`size`),
  KEY `difficulty` (`difficulty`),
  KEY `terrain` (`terrain`),
  KEY `wp_gc_maintained` (`wp_gc_maintained`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caches`
--

LOCK TABLES `caches` WRITE;
/*!40000 ALTER TABLE `caches` DISABLE KEYS */;
/*!40000 ALTER TABLE `caches` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cachesBeforeInsert` BEFORE INSERT ON `caches`
     FOR EACH ROW BEGIN
        SET @dont_update_listingdate=1;

        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            SET NEW.`date_created`=NOW();
            SET NEW.`last_modified`=NOW();
            SET NEW.`listing_last_modified`=NOW();
        END IF;
        IF NEW.`status` <> 5 THEN
            SET NEW.`is_publishdate`=1;
        END IF;
        IF SUBSTR(TRIM(NEW.`wp_gc`),1,2)='GC' THEN
            SET NEW.`wp_gc_maintained`=UCASE(TRIM(NEW.`wp_gc`));
        END IF;
        SET NEW.`need_npa_recalc`=1;

        IF ISNULL(NEW.`uuid`) OR NEW.`uuid`='' THEN
            SET NEW.`uuid`=CREATE_UUID();
        END IF;

        /* reserve and set cache waypoint
         *
         * Table cache_waypoint_pool is used to prevent race conditions
         * when 2 caches will be inserted simultaneously
         */
        IF ISNULL(NEW.`wp_oc`) OR NEW.`wp_oc`='' THEN

            /* cleanup previous assignments failures /*
            DELETE FROM `cache_waypoint_pool` WHERE `uuid`=NEW.`uuid`;

            /* reserve a waypoint */
            UPDATE `cache_waypoint_pool`
            SET `uuid`=NEW.`uuid`
            WHERE `uuid` IS NULL ORDER BY WPTODEC(`wp_oc`, 'AA') ASC LIMIT 1;
                    
            IF (SELECT COUNT(*) FROM `cache_waypoint_pool` WHERE `uuid`=NEW.`uuid`) = 0 THEN

                /* waypoint reservation was not successfull. Maybe we are on a development machine, where cronjob for waypoint pool
                 * generation did not run or the pool is empty. To get a valid waypoint, we simply increment the highest used waypoint by one.
                 * NOTE: This ignores the setting of opt[logic][waypoint_pool][fill_gaps]
                 * CAUTION: This statement is realy slow and you should always keep your waypoint pool filled with some waypoint on a production server
                 */
                INSERT INTO `cache_waypoint_pool` (`wp_oc`, `uuid`)
                    SELECT DECTOWP(MAX(`dec_wp`)+1, 'AA'), NEW.`uuid` AS `uuid`
                    FROM
                        (SELECT MAX(WPTODEC(`wp_oc`, 'AA')) AS dec_wp FROM `caches` WHERE `wp_oc` REGEXP '^AA[0123456789ABCDEF]{1,}$'
                         UNION SELECT MAX(WPTODEC(`wp_oc`, 'AA')) AS dec_wp FROM `cache_waypoint_pool`
                        ) AS `tbl`;
            END IF;

            /* query and assign the reserved waypoint */
            SET NEW.`wp_oc` =
                (SELECT `wp_oc` FROM `cache_waypoint_pool` WHERE `uuid`=`NEW`.`uuid`);
        END IF;

        SET @dont_update_listingdate=0;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cachesAfterInsert` AFTER INSERT ON `caches`
     FOR EACH ROW BEGIN
        SET @dont_update_listingdate=1;

        INSERT IGNORE INTO `cache_coordinates` (`cache_id`, `date_created`, `longitude`, `latitude`)
        VALUES (NEW.`cache_id`, NOW(), NEW.`longitude`, NEW.`latitude`);

        INSERT IGNORE INTO `cache_countries` (`cache_id`, `date_created`, `country`)
        VALUES (NEW.`cache_id`, NOW(), NEW.`country`);

        CALL sp_update_hiddenstat(NEW.`user_id`, NEW.`status`, FALSE);

        IF NEW.`status`=1 THEN
            CALL sp_notify_new_cache(NEW.`cache_id`, NEW.`longitude`, NEW.`latitude`, 1);
        END IF;

        /* cleanup/delete reserved waypoint */
        DELETE FROM `cache_waypoint_pool` WHERE `uuid`=NEW.`uuid`;

        SET @dont_update_listingdate=0;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cachesBeforeUpdate` BEFORE UPDATE ON `caches`
     FOR EACH ROW BEGIN
        SET @dont_update_listingdate=1;

        /* The first IF condition is necessary so that the NM/LO flags
         * can be updated by a log which also changes the cache state,
         * independently of the order of log-insertion and cache-state-update.
         */
        IF NEW.`status` != OLD.`status` AND NEW.`status` IN (4,5,6,7) THEN
            SET NEW.`needs_maintenance`=0;
            SET NEW.`listing_outdated`=0;
        END IF;

        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            IF
                OLD.`cache_id`!=NEW.`cache_id`
                OR OLD.`uuid`!=BINARY NEW.`uuid`
                OR OLD.`node`!=NEW.`node`
                OR OLD.`date_created`!=NEW.`date_created`
                OR OLD.`is_publishdate`!=NEW.`is_publishdate`
                OR OLD.`user_id`!=NEW.`user_id`
                OR OLD.`name`!=BINARY NEW.`name`
                OR OLD.`longitude`!=NEW.`longitude`
                OR OLD.`latitude`!=NEW.`latitude`
                OR OLD.`type`!=NEW.`type`
                OR OLD.`status`!=NEW.`status`
                OR OLD.`country`!=BINARY NEW.`country`
                OR OLD.`date_hidden`!=NEW.`date_hidden`
                OR OLD.`size`!=NEW.`size`
                OR OLD.`difficulty`!=NEW.`difficulty`
                OR OLD.`terrain`!=NEW.`terrain`
                OR OLD.`logpw`!=BINARY NEW.`logpw`
                OR OLD.`search_time`!=NEW.`search_time`
                OR OLD.`way_length`!=NEW.`way_length`
                OR OLD.`wp_gc`!=BINARY NEW.`wp_gc`
                OR OLD.`wp_nc`!=BINARY NEW.`wp_nc`
                OR OLD.`wp_oc`!=BINARY NEW.`wp_oc`
                OR OLD.`default_desclang`!=BINARY NEW.`default_desclang`
                OR OLD.`date_activate`!=NEW.`date_activate`
                OR OLD.`show_cachelists`!=NEW.`show_cachelists`
            THEN
                SET NEW.`last_modified`=NOW();
            END IF;

            IF
                OLD.`needs_maintenance`!=NEW.`needs_maintenance`
                OR OLD.`listing_outdated`!=NEW.`listing_outdated`
                OR OLD.`wp_gc_maintained`!=NEW.`wp_gc_maintained`
            THEN
                SET NEW.`flags_last_modified`=NOW();
            END IF;

            IF NEW.`last_modified` != OLD.`last_modified` THEN
                SET NEW.`listing_last_modified`=NOW();
            END IF;

            IF OLD.`status`!=NEW.`status` THEN
                CALL sp_touch_cache(OLD.`cache_id`, FALSE);
            END IF;
        END IF;

        IF
            NEW.`wp_gc`<>OLD.`wp_gc` AND
            (SUBSTR(TRIM(NEW.`wp_gc`),1,2)='GC' OR TRIM(NEW.`wp_gc`)='')
        THEN
            SET NEW.`wp_gc_maintained`=UCASE(TRIM(NEW.`wp_gc`));
        END IF;

        IF OLD.`longitude`!=NEW.`longitude` OR OLD.`latitude`!=NEW.`latitude` THEN
            SET NEW.`need_npa_recalc`=1;
        END IF;

        IF OLD.`status`=5 AND NEW.`status`<>5 THEN
            SET NEW.`date_created`=NOW();
            SET NEW.`is_publishdate`=1;
        END IF;

        SET @dont_update_listingdate=0;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cachesAfterUpdate` AFTER UPDATE ON `caches`
     FOR EACH ROW BEGIN
        SET @dont_update_listingdate=1;

        IF
            ROUND(NEW.`longitude`,6) != ROUND(OLD.`longitude`,6)
            OR ROUND(NEW.`latitude`,6) != ROUND(OLD.`latitude`,6)
        THEN
            INSERT IGNORE INTO `cache_coordinates`
                (`cache_id`, `date_created`, `longitude`, `latitude`, `restored_by`)
            VALUES (NEW.`cache_id`, NOW(), NEW.`longitude`, NEW.`latitude`, IFNULL(@restoredby,0));
        END IF;

        IF NEW.`country` != OLD.`country` THEN
            INSERT IGNORE INTO `cache_countries`
                (`cache_id`, `date_created`, `country`, `restored_by`)
            VALUES (NEW.`cache_id`, NOW(), NEW.`country`, IFNULL(@restoredby,0));
        END IF;

        IF
            NEW.`cache_id` = OLD.`cache_id`
            AND OLD.`status` <> 5
            AND OLD.`date_created` < LEFT(NOW(),10)
            AND (
                NEW.`name` != OLD.`name`
                OR NEW.`type` != OLD.`type`
                OR NEW.`date_hidden` != OLD.`date_hidden`
                OR NEW.`size` != OLD.`size`
                OR NEW.`difficulty` != OLD.`difficulty`
                OR NEW.`terrain` != OLD.`terrain`
                OR NEW.`search_time` != OLD.`search_time`
                OR NEW.`way_length` != OLD.`way_length`
                OR NEW.`wp_gc` != OLD.`wp_gc`
                OR NEW.`wp_nc` != OLD.`wp_nc`
            )
        THEN
            INSERT IGNORE INTO `caches_modified` (
                `cache_id`, `date_modified`, `name`, `type`, `date_hidden`, `size`,
                `difficulty`, `terrain`, `search_time`, `way_length`, `wp_gc`,
                `wp_nc`, `restored_by`
            ) VALUES (
                OLD.`cache_id`, NOW(), OLD.`name`, OLD.`type`, OLD.`date_hidden`, OLD.`size`,
                OLD.`difficulty`, OLD.`terrain`, OLD.`search_time`, OLD.`way_length`, OLD.`wp_gc`,
                OLD.`wp_nc`, IFNULL(@restoredby,0)
            );
            /* logpw needs not to be saved */
            /* for further explanation see restorecaches.php */
        END IF;

        IF NEW.`user_id`!=OLD.`user_id` THEN
            INSERT INTO `cache_adoptions` (`cache_id`,`date`,`from_user_id`,`to_user_id`)
            VALUES (NEW.`cache_id`, NEW.`last_modified`, OLD.`user_id`, NEW.`user_id`);
        END IF;
        IF NEW.`user_id`!=OLD.`user_id` OR NEW.`status`!=OLD.`status` THEN
            CALL sp_update_hiddenstat(OLD.`user_id`, OLD.`status`, TRUE);
            CALL sp_update_hiddenstat(NEW.`user_id`, NEW.`status`, FALSE);
        END IF;
        IF OLD.`status`=5 AND NEW.`status`=1 THEN
            CALL sp_notify_new_cache(NEW.`cache_id`, NEW.`longitude`, NEW.`latitude`, 1);
        END IF;
        IF NEW.`status`<>OLD.`status` THEN
            INSERT INTO `cache_status_modified`
                (`cache_id`, `date_modified`, `old_state`, `new_state`, `user_id`)
            VALUES (NEW.`cache_id`, NOW(), OLD.`status`, NEW.`status`, IFNULL(@STATUS_CHANGE_USER_ID,0));
        END IF;
        
        SET @dont_update_listingdate=0;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cachesBeforeDelete` BEFORE DELETE ON `caches`
     FOR EACH ROW BEGIN
        IF IFNULL(@allowdelete,0) = 0 THEN
            CALL error_set_allowdelete_to_delete_caches();
            /*
                There are exactly three reasons to delete a cache record:

                1. Get rid of obsolete data on a test or developer machine.
                2. Get rid of a bad cache record which was left over by a cache creating bug.
                3. Remove replicated data from other nodes which are no longer useful.

                Do NOT delete a cache record for any other reason!
            */
        ELSEIF IFNULL(@fastdelete,0) = 0 THEN
            /*
                use 'fastdelete' only to delete bulk data and if you are sure that
                you can handle all dependent data on your own
            */
            SET @dont_update_listingdate=1;
            SET @deleting_cache=1;
            
            DELETE FROM `cache_adoption` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_adoptions` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_coordinates` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_countries` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_desc` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_desc_modified` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_ignore` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_list_items` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_location` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_logs` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_logs_archived` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_maps` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_npa_areas` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_rating` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_reports` WHERE `cacheid`=OLD.`cache_id`;   /* cacheid ! */
            DELETE FROM `cache_status_modified` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_visits` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `cache_watches` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `caches_attributes` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `caches_attributes_modified` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `caches_modified` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `coordinates` WHERE `cache_id`=OLD.`cache_id`;
            /*
                DELETE FROM `map2_data` WHERE `cache_id`=OLD.`cache_id`;

                Adding an cache_id index to map2_data would be performance-critical.
                The leftover data won't hurt and will be deleted by a cronjob.
            */
            DELETE FROM `notify_waiting` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `pictures` WHERE `object_type`=2 AND `object_id`=OLD.`cache_id`;
            DELETE FROM `rating_tops` WHERE `cache_id`=OLD.`cache_id`;
            /*
                DELETE FROM `search_index` WHERE `cache_id`=OLD.`cache_id`;
                DELETE FROM `search_index_times` WHERE `object_type`=2 AND `object_id`=OLD.`cache_id`;

                Deleting this would be performance critical.
                The leftover data won't hurt and will be automaticall rebuilt via cronjob.
            */
            DELETE FROM `stat_cache_logs` WHERE `cache_id`=OLD.`cache_id`;
            DELETE FROM `stat_caches` WHERE `cache_id`=OLD.`cache_id`;
            
            SET @dont_update_listingdate=0;
            SET @deleting_cache=0;
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cachesAfterDelete` AFTER DELETE ON `caches`
     FOR EACH ROW BEGIN
        INSERT IGNORE INTO `removed_objects` (`localId`, `uuid`, `type`, `node`)
        VALUES (OLD.`cache_id`, OLD.`uuid`, 2, OLD.`node`);
        
        CALL sp_update_hiddenstat(OLD.`user_id`, OLD.`status`, TRUE);
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
