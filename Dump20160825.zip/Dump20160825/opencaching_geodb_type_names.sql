-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `geodb_type_names`
--

DROP TABLE IF EXISTS `geodb_type_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geodb_type_names` (
  `type_id` int(11) NOT NULL,
  `type_locale` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  UNIQUE KEY `type_id` (`type_id`,`type_locale`),
  KEY `tid_tnames_idx` (`type_id`),
  KEY `locale_tnames_idx` (`type_locale`),
  KEY `name_tnames_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geodb_type_names`
--

LOCK TABLES `geodb_type_names` WRITE;
/*!40000 ALTER TABLE `geodb_type_names` DISABLE KEYS */;
INSERT INTO `geodb_type_names` VALUES (500600000,'de','Amtlicher GemeindeschlÃ¼ssel'),(300400000,'de','Auf 10 Jahre genaues Datum'),(300300000,'de','Auf ein Jahr genaues Datum'),(300200000,'de','Auf ein Monat genaues Datum'),(300100000,'de','Auf einen Tag genaues Datum'),(1,'de','beliebig'),(100300000,'de_DE','Bundesland'),(650800003,'de','Durchschnittliche HÃ¶he'),(400200000,'de','Ebene'),(600700000,'de','Einwohnerzahl'),(100100000,'de','Erdteil'),(610000000,'de','FlÃ¤che'),(650700002,'de','Genaue Einwohnerzahl'),(650800004,'de','HÃ¶he am Referenzpunkt mit der angegebenen loc_id'),(650800005,'de','HÃ¶he an der angegebenen Koordinate'),(600800000,'de','HÃ¶henangabe in Metern'),(500100001,'de','ISO 3166 Alpha-2'),(500100003,'de','ISO_3166_2'),(100300000,'de_CH','Kanton'),(500500000,'de','KFZ-Kennzeichen'),(500900000,'de','Kommentar'),(100500000,'de','Landkreis'),(200200000,'de','lat'),(200300000,'de','lon'),(650800001,'de','Maximale HÃ¶he'),(650800002,'de','Minimale HÃ¶he'),(500100000,'de','Name'),(0,'de','nicht vorhanden'),(100700000,'de','Ortschaft'),(100900000,'de','Ortsteil'),(100600000,'de','Politische Gliederung'),(500300000,'de','Postleitzahl'),(100800000,'de','Postleitzahlgebiet'),(500800000,'de','Quelle'),(100400000,'de','Regierungsbezirk'),(500100004,'de','Region eines Postleitzahlgebietes'),(500100002,'de','Sortiername'),(500700001,'de','Sortiername eines Verwaltungszusammenschlusses'),(100200000,'de','Staat/Land'),(400100000,'de','Teil von'),(500400000,'de','Telefonvorwahl'),(400300000,'de','Typ'),(300500000,'de','Unbekanntes Datum in der Zukunft'),(650700001,'de','UngefÃ¤hre Einwohnerzahl'),(500700000,'de','Verwaltungszusammenschluss'),(200100000,'de','WGS84 Koordinaten'),(-1,'de','[unbekannt]');
/*!40000 ALTER TABLE `geodb_type_names` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
