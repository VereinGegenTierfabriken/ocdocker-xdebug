-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `geodb_hierarchies`
--

DROP TABLE IF EXISTS `geodb_hierarchies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geodb_hierarchies` (
  `loc_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `id_lvl1` int(11) NOT NULL,
  `id_lvl2` int(11) DEFAULT NULL,
  `id_lvl3` int(11) DEFAULT NULL,
  `id_lvl4` int(11) DEFAULT NULL,
  `id_lvl5` int(11) DEFAULT NULL,
  `id_lvl6` int(11) DEFAULT NULL,
  `id_lvl7` int(11) DEFAULT NULL,
  `id_lvl8` int(11) DEFAULT NULL,
  `id_lvl9` int(11) DEFAULT NULL,
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL,
  `date_type_until` int(11) NOT NULL,
  KEY `hierarchy_loc_id_idx` (`loc_id`),
  KEY `hierarchy_level_idx` (`level`),
  KEY `hierarchy_lvl1_idx` (`id_lvl1`),
  KEY `hierarchy_lvl2_idx` (`id_lvl2`),
  KEY `hierarchy_lvl3_idx` (`id_lvl3`),
  KEY `hierarchy_lvl4_idx` (`id_lvl4`),
  KEY `hierarchy_lvl5_idx` (`id_lvl5`),
  KEY `hierarchy_lvl6_idx` (`id_lvl6`),
  KEY `hierarchy_lvl7_idx` (`id_lvl7`),
  KEY `hierarchy_lvl8_idx` (`id_lvl8`),
  KEY `hierarchy_lvl9_idx` (`id_lvl9`),
  KEY `hierarchy_since_idx` (`valid_since`),
  KEY `hierarchy_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geodb_hierarchies`
--

LOCK TABLES `geodb_hierarchies` WRITE;
/*!40000 ALTER TABLE `geodb_hierarchies` DISABLE KEYS */;
/*!40000 ALTER TABLE `geodb_hierarchies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
