-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pictures`
--

DROP TABLE IF EXISTS `pictures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pictures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `node` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL COMMENT 'via Trigger (pictures)',
  `last_modified` datetime NOT NULL COMMENT 'via Trigger (pictures)',
  `url` varchar(255) NOT NULL,
  `title` varchar(250) NOT NULL,
  `last_url_check` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0',
  `object_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `thumb_url` varchar(255) NOT NULL,
  `thumb_last_generated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `spoiler` tinyint(1) NOT NULL DEFAULT '0',
  `local` tinyint(1) NOT NULL DEFAULT '1',
  `unknown_format` tinyint(1) NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '1',
  `mappreview` tinyint(1) NOT NULL DEFAULT '0',
  `seq` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `object_type` (`object_type`,`object_id`,`seq`),
  KEY `last_modified` (`last_modified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pictures`
--

LOCK TABLES `pictures` WRITE;
/*!40000 ALTER TABLE `pictures` DISABLE KEYS */;
/*!40000 ALTER TABLE `pictures` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `picturesBeforeInsert` BEFORE INSERT ON `pictures`
     FOR EACH ROW BEGIN
        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            SET NEW.`date_created`=NOW();
            SET NEW.`last_modified`=NOW();
            IF NEW.`seq` = 0 THEN
                SET NEW.`seq` =
                    IFNULL(
                        (SELECT MAX(`seq`)+1
                         FROM `pictures`
                         WHERE `object_type`=NEW.`object_type` AND `object_id`=NEW.`object_id`
                        ),
                        1
                    );
            END IF;
        END IF;
        IF ISNULL(NEW.`uuid`) OR NEW.`uuid`='' THEN
            SET NEW.`uuid`=CREATE_UUID();
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `picturesAfterInsert` AFTER INSERT ON `pictures`
     FOR EACH ROW BEGIN
        IF
            @archive_picop
            AND (
                NEW.`object_type`=1   /* re-insert of owner-deleted other user's logpic */
                OR (
                    NEW.`object_type`=2
                    AND (SELECT `date_created` FROM `caches` WHERE `cache_id`=NEW.`object_id`) < LEFT(NOW(),10)
                    AND (SELECT `status` FROM `caches` WHERE `caches`.`cache_id`=NEW.`object_id`) != 5
                )
            )
        THEN
           INSERT IGNORE INTO `pictures_modified`
               (`id`, `date_modified`, `operation`, `object_type`, `object_id`, `title`, `original_id`, `restored_by`)
           VALUES (
               NEW.`id`, NOW(), 'I', NEW.`object_type`, NEW.`object_id`, NEW.`title`,
               IFNULL(@original_picid, 0), IFNULL(@restoredby, 0)
           );
        END IF;
        IF NEW.`object_type`=1 THEN
           CALL sp_update_cachelog_picturestat(NEW.`object_id`, FALSE);
        ELSEIF NEW.`object_type`=2 THEN
           CALL sp_update_cache_picturestat(NEW.`object_id`, FALSE);
           CALL sp_update_cache_listingdate(NEW.`object_id`);
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `picturesBeforeUpdate` BEFORE UPDATE ON `pictures`
     FOR EACH ROW BEGIN
        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            IF
                NEW.`id`!=OLD.`id`
                OR NEW.`uuid`!=BINARY OLD.`uuid`
                OR NEW.`node`!=OLD.`node`
                OR NEW.`date_created`!=OLD.`date_created`
                OR NEW.`url`!=BINARY OLD.`url`
                OR NEW.`title`!=BINARY OLD.`title`
                OR NEW.`object_id`!=OLD.`object_id`
                OR NEW.`object_type`!=OLD.`object_type`
                OR NEW.`spoiler`!=OLD.`spoiler`
                OR NEW.`local`!=OLD.`local`
                OR NEW.`unknown_format`!=OLD.`unknown_format`
                OR NEW.`display`!=OLD.`display`
                OR NEW.`mappreview`!=OLD.`mappreview`
                OR NEW.`seq`!=OLD.`seq`
            THEN
                /* everything except last_url_check, thumb_url and thumb_last_generated */
                SET NEW.`last_modified`=NOW();
            END IF;
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `picturesAfterUpdate` AFTER UPDATE ON `pictures`
     FOR EACH ROW BEGIN
        IF OLD.`object_type`!=NEW.`object_type` OR OLD.`object_id`!=NEW.`object_id` THEN
            IF OLD.`object_type`=1 THEN
                CALL sp_update_cachelog_picturestat(OLD.`object_id`, TRUE);
            ELSEIF OLD.`object_type`=2 THEN
                CALL sp_update_cache_picturestat(OLD.`object_id`, TRUE);
                CALL sp_update_cache_listingdate(OLD.`object_id`);
            END IF;
            IF NEW.`object_type`=1 THEN
                CALL sp_update_cachelog_picturestat(NEW.`object_id`, FALSE);
            ELSEIF NEW.`object_type`=2 THEN
                CALL sp_update_cache_picturestat(NEW.`object_id`, FALSE);
                CALL sp_update_cache_listingdate(NEW.`object_id`);
            END IF;
        ELSE
            IF NEW.`last_modified` != OLD.`last_modified` THEN
                IF NEW.`object_type`=1 THEN
                    IF NOT IFNULL(@dont_update_logdate,FALSE) THEN
                        UPDATE `cache_logs` SET `log_last_modified`=NEW.`last_modified` WHERE `id`=NEW.`object_id`;
                    END IF;
                ELSE
                    CALL sp_update_cache_listingdate(NEW.`object_id`);
                END IF;
            END IF;
            /* cache_logs.entry_last_modified MUST ONLY be changed if the visible log entry changes! */
            IF
                NEW.`object_type`=1
                AND NOT IFNULL(@dont_update_logdate,FALSE)
                AND (NEW.`title`!=BINARY OLD.`title` OR NEW.`spoiler`!=OLD.`spoiler`)
            THEN
                UPDATE `cache_logs` SET `entry_last_modified`=NEW.`last_modified` WHERE `id`=NEW.`object_id`;
            END IF;
            IF
                @archive_picop
                AND (
                        (
                            NEW.`object_type`=2
                            AND OLD.`date_created` < LEFT(NOW(),10)
                            AND (SELECT `status` FROM `caches` WHERE `caches`.`cache_id`=OLD.`object_id`) != 5
                        )
                        OR NEW.`object_type`=1
                )
                AND (
                    NEW.`title` != OLD.`title`
                    OR NEW.`spoiler` != OLD.`spoiler`
                    OR NEW.`display` != OLD.`display`
                )
            THEN
                INSERT IGNORE INTO `pictures_modified`
                    (`id`, `date_modified`, `operation`, `date_created`, `url`, `title`,
                     `object_id`, `object_type`, `spoiler`, `unknown_format`,
                     `display`, `restored_by`)
                VALUES (
                    OLD.`id`, NOW(), 'U', OLD.`date_created`, OLD.`url`, OLD.`title`,
                    OLD.`object_id`, OLD.`object_type`, OLD.`spoiler`, OLD.`unknown_format`,
                    OLD.`display`, IFNULL(@restoredby,0)
                );
                /* mappreview is not archived, can be safely set to 0 on restore */
            END IF;
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `picturesAfterDelete` AFTER DELETE ON `pictures`
     FOR EACH ROW BEGIN
        INSERT IGNORE INTO `removed_objects` (`localId`, `uuid`, `type`, `node`)
        VALUES (OLD.`id`, OLD.`uuid`, 6, OLD.`node`);

        IF
            @archive_picop AND
            (
                OLD.`object_type`=1
                    /* @archive_picop ensures that type-1 pics here are non-cacheowner's pics */
                OR (
                    OLD.`object_type`=2
                    AND (SELECT `date_created` FROM `caches` WHERE `cache_id`=OLD.`object_id`) < LEFT(NOW(),10)
                    AND (SELECT `status` FROM `caches` WHERE `caches`.`cache_id`=OLD.`object_id`) != 5
                )
            )
        THEN
            INSERT IGNORE INTO `pictures_modified`
                (`id`, `date_modified`, `operation`, `date_created`, `url`, `title`,
                 `object_id`, `object_type`, `spoiler`, `unknown_format`,
                 `display`, `restored_by`)
            VALUES (
                OLD.`id`, NOW(), 'D', OLD.`date_created`, OLD.`url`, OLD.`title`,
                OLD.`object_id`, OLD.`object_type`, OLD.`spoiler`, OLD.`unknown_format`,
                OLD.`display`, IFNULL(@restoredby,0)
            );
            /* mappreview is not archived, can be safely set to 0 on restore */
        END IF;

        IF OLD.`object_type`=1 THEN
            CALL sp_update_cachelog_picturestat(OLD.`object_id`, TRUE);
        ELSEIF OLD.`object_type`=2 THEN
            CALL sp_update_cache_picturestat(OLD.`object_id`, TRUE);
            CALL sp_update_cache_listingdate(OLD.`object_id`);
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
