-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile_options`
--

DROP TABLE IF EXISTS `profile_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `trans_id` int(10) unsigned NOT NULL,
  `internal_use` tinyint(1) NOT NULL DEFAULT '1',
  `default_value` text,
  `check_regex` varchar(255) DEFAULT NULL,
  `option_order` int(11) NOT NULL DEFAULT '100',
  `option_input` varchar(20) NOT NULL DEFAULT 'text',
  `optionset` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='static content';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_options`
--

LOCK TABLES `profile_options` WRITE;
/*!40000 ALTER TABLE `profile_options` DISABLE KEYS */;
INSERT INTO `profile_options` VALUES (1,'MiniMap-Zoom',748,1,'11','^[1-9][0-9]{0,1}$',0,'text',1),(2,'Location',747,0,'','^.*$',10,'text',1),(3,'Description',114,0,'',NULL,100,'textarea',3),(4,'Age',745,0,'','^[[0-9]+$',80,'text',1),(5,'Show statistics',744,1,'1','^[0-1]$',50,'checkbox',1),(6,'Menu option \'Map\' shows:',1867,1,'1','^[0-1]$',110,'select:0=small map,1',2),(7,'Show overview map:',1870,1,'0','^[0-1]$',120,'checkbox',2),(8,'Maximum caches on map<br />(%1-%2, 0=automatic):',1871,1,'0','^[0-9]{1,4}$',130,'text',2),(9,'Cache icons:',1872,1,'1','^[1-9]$',140,'select:1=classic OC,',2),(10,'Show %1preview pictures</a><br />(% of map area, 0=off):',1928,1,'7','^[0-5]?[0-9]$',150,'text',2),(11,'Show picture stats and gallery',1944,1,'1','^[0-1]$',60,'checkbox',1),(13,'Show OConly-81 stats',2135,1,'0','^[0-1]$',65,'checkbox',1),(14,'Auto-load log entries',2153,1,'1','^[0-1]$',15,'checkbox',1);
/*!40000 ALTER TABLE `profile_options` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
