-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache_logs`
--

DROP TABLE IF EXISTS `cache_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `node` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL COMMENT 'via Trigger (cache_logs)',
  `entry_last_modified` datetime NOT NULL COMMENT 'via Trigger (cache_logs)',
  `last_modified` datetime NOT NULL COMMENT 'via Trigger (cache_logs)',
  `log_last_modified` datetime NOT NULL COMMENT 'via Triggers',
  `cache_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `oc_team_comment` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `order_date` datetime NOT NULL,
  `needs_maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `listing_outdated` tinyint(1) NOT NULL DEFAULT '0',
  `text` longtext NOT NULL,
  `text_html` tinyint(1) NOT NULL DEFAULT '1',
  `text_htmledit` tinyint(1) NOT NULL DEFAULT '1',
  `owner_notified` tinyint(1) NOT NULL DEFAULT '0',
  `picture` smallint(5) unsigned NOT NULL COMMENT 'via Trigger (picture)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `owner_notified` (`owner_notified`),
  KEY `last_modified` (`last_modified`),
  KEY `type` (`type`,`cache_id`),
  KEY `date_created` (`date_created`),
  KEY `user_id` (`user_id`,`cache_id`),
  KEY `cache_id` (`cache_id`,`user_id`),
  KEY `date` (`cache_id`,`date`,`date_created`),
  KEY `order_date` (`cache_id`,`order_date`,`date_created`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='Attention: modifications to this table may need to be applied also to cache_logs_archived, cache_logs_modified and trigger cacheLogsBeforeUpdate!';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_logs`
--

LOCK TABLES `cache_logs` WRITE;
/*!40000 ALTER TABLE `cache_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheLogsBeforeInsert` BEFORE INSERT ON `cache_logs`
     FOR EACH ROW BEGIN
        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            SET NEW.`date_created`=NOW();
            SET NEW.`entry_last_modified`=NEW.`date_created`;
            SET NEW.`last_modified`=NEW.`date_created`;
            SET NEW.`log_last_modified`=NEW.`date_created`;
            SET NEW.`order_date`=
                IF(
                    RIGHT(NEW.`date`, 8) <> '00:00:00' OR NEW.`date` > NEW.`date_created`,
                    NEW.`date`,
                    IF(
                        LEFT(NEW.`date_created`, 10) = LEFT(NEW.`date`, 10),
                        NEW.`date_created`,
                        CONCAT(LEFT(NEW.`date`, 11), '23:59:58')
                    )
                );
        END IF;

        IF ISNULL(NEW.`uuid`) OR NEW.`uuid`='' THEN
            SET NEW.`uuid`=CREATE_UUID();
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheLogsAfterInsert` AFTER INSERT ON `cache_logs`
     FOR EACH ROW BEGIN
        DECLARE done INT DEFAULT 0;
        DECLARE notify_user_id INT;
        DECLARE cur1 CURSOR FOR

        /* see also EmailRecovery::resendLogNotifications() */

        /* watches from `cache_watches` */
        SELECT `cache_watches`.`user_id`
        FROM `cache_watches`
        INNER JOIN `caches` ON `cache_watches`.`cache_id`=`caches`.`cache_id`
        INNER JOIN `cache_status` ON `caches`.`status`=`cache_status`.`id`
        WHERE `cache_watches`.`cache_id`=NEW.cache_id AND `cache_status`.`allow_user_view`=1
        UNION    /* UNION discards duplicates */
        /* watches from `cache_list_watches` */
        SELECT `clw`.`user_id` FROM `cache_list_watches` `clw`
        INNER JOIN `cache_list_items` `cli` ON `clw`.`cache_list_id`=`cli`.`cache_list_id`
        INNER JOIN `caches` ON `cli`.`cache_id`=`caches`.`cache_id`
        INNER JOIN `cache_status` ON `caches`.`status`=`cache_status`.`id`
        WHERE `cli`.`cache_id`=NEW.cache_id AND `cache_status`.`allow_user_view`=1;

        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

        CALL sp_update_logstat(NEW.`cache_id`, NEW.`user_id`, NEW.`type`, FALSE);

        OPEN cur1;
        REPEAT
            FETCH cur1 INTO notify_user_id;
            IF NOT done THEN
                INSERT INTO `watches_logqueue` (`log_id`, `user_id`) VALUES (NEW.id, notify_user_id);
            END IF;
        UNTIL done END REPEAT;
        CLOSE cur1;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheLogsBeforeUpdate` BEFORE UPDATE ON `cache_logs`
     FOR EACH ROW BEGIN
        /* dont overwrite `last_modified` while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            IF
                NEW.`id`!=OLD.`id`
                OR NEW.`uuid`!=BINARY OLD.`uuid`
                OR NEW.`node`!=OLD.`node`
                OR NEW.`date_created`!=OLD.`date_created`
                OR NEW.`cache_id`!=OLD.`cache_id`
                OR NEW.`user_id`!=OLD.`user_id`
                OR NEW.`type`!=OLD.`type`
                OR NEW.`oc_team_comment`!=OLD.`oc_team_comment`
                OR NEW.`date`!=OLD.`date`
                OR NEW.`needs_maintenance`!=OLD.`needs_maintenance`
                OR NEW.`listing_outdated`!=OLD.`listing_outdated`
                OR NEW.`text`!=BINARY OLD.`text`
                OR NEW.`text_html`!=OLD.`text_html`
            THEN
                SET NEW.`log_last_modified`=NEW.`date_created`;
                SET NEW.`order_date` =
                    IF(
                        RIGHT(NEW.`date`, 8) <> '00:00:00' OR NEW.`date` > NEW.`date_created`,
                        NEW.`date`,
                        IF(
                            LEFT(NEW.`date_created`, 10) = LEFT(NEW.`date`, 10), NEW.`date_created`,
                            CONCAT(LEFT(NEW.`date`, 11),
                            '23:59:58')
                        )
                    );

                /* log versioning to allow log vandalism restore (except pictures);
                 * optimize storage space by ignoring quick-corrections of logs
                 */
                IF DATEDIFF(NOW(), OLD.`date_created`) > 1 THEN
                    INSERT IGNORE INTO `cache_logs_modified`
                        (`id`, `uuid`, `node`, `date_created`, `entry_last_modified`, `last_modified`,
                         `log_last_modified`, `cache_id`, `user_id`, `type`, `oc_team_comment`, `date`,
                         `needs_maintenance`, `listing_outdated`, `text`, `text_html`, `modify_date`
                        )
                    VALUES (
                        OLD.`id`, OLD.`uuid`, OLD.`node`, OLD.`date_created`, OLD.`entry_last_modified`, OLD.`last_modified`,
                        OLD.`log_last_modified`, OLD.`cache_id`, OLD.`user_id`, OLD.`type`, OLD.`oc_team_comment`, OLD.`date`,
                        OLD.`needs_maintenance`, OLD.`listing_outdated`, OLD.`text`, OLD.`text_html`, NOW()
                    );
                END IF;

                SET NEW.`last_modified`=NOW();
            END IF;
            
            /* entry_last_modified MUST ONLY be changed if the visible log entry changes! */
            IF
                NEW.`type`!=OLD.`type`
                OR NEW.`oc_team_comment`!=OLD.`oc_team_comment`
                OR NEW.`date`!=OLD.`date`
                OR NEW.`needs_maintenance`!=OLD.`needs_maintenance`
                OR NEW.`listing_outdated`!=OLD.`listing_outdated`
                OR NEW.`text`!=BINARY OLD.`text`
                OR NEW.`picture`!=OLD.`picture`
            THEN
                SET NEW.`entry_last_modified`=NOW();
            END IF;
            IF NEW.`picture`!=OLD.`picture` THEN
                SET NEW.`log_last_modified`=NOW();
            END IF;
            IF NEW.`last_modified` > NEW.`log_last_modified` THEN
                SET NEW.`log_last_modified`=NEW.`last_modified`;
            END IF;
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheLogsAfterUpdate` AFTER UPDATE ON `cache_logs`
     FOR EACH ROW BEGIN
        IF
            OLD.`cache_id`!=NEW.`cache_id`
            OR OLD.`user_id`!=NEW.`user_id`
            OR OLD.`type`!=NEW.`type`
            OR OLD.`date`!=NEW.`date`
        THEN
            CALL sp_update_logstat(OLD.`cache_id`, OLD.`user_id`, OLD.`type`, TRUE);
            CALL sp_update_logstat(NEW.`cache_id`, NEW.`user_id`, NEW.`type`, FALSE);
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheLogsBeforeDelete` BEFORE DELETE ON `cache_logs`
     FOR EACH ROW BEGIN
        /* Pictures normally are deleted via removelog.php, which may save the
           picture file for vandalism restore. This is only for debugging or
           for deleting imported data from other nodes.
           Ratings may be leftover in cache_rating and need to be cleaned up elswhere
        */
        SET @deleting_log=1;
        DELETE FROM `pictures` WHERE `object_type`=1 AND `object_id`=OLD.`id`;
        DELETE FROM `cache_logs_restored` WHERE `cache_logs_restored`.`id`=OLD.`id`;
        SET @deleting_log=0;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheLogsAfterDelete` AFTER DELETE ON `cache_logs`
     FOR EACH ROW BEGIN
        CALL sp_update_logstat(OLD.`cache_id`, OLD.`user_id`, OLD.`type`, TRUE);

        INSERT IGNORE INTO `removed_objects` (`localId`, `uuid`, `type`, `node`)
        VALUES (OLD.`id`, OLD.`uuid`, 1, OLD.`node`);
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
