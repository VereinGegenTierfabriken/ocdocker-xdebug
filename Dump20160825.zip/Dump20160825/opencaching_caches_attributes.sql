-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caches_attributes`
--

DROP TABLE IF EXISTS `caches_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caches_attributes` (
  `cache_id` int(10) unsigned NOT NULL,
  `attrib_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`cache_id`,`attrib_id`),
  KEY `attrib_id` (`attrib_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caches_attributes`
--

LOCK TABLES `caches_attributes` WRITE;
/*!40000 ALTER TABLE `caches_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `caches_attributes` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheAttributesAfterInsert` AFTER INSERT ON `caches_attributes`
     FOR EACH ROW BEGIN
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            UPDATE `caches` SET `last_modified`=NOW() WHERE `cache_id`=NEW.`cache_id`;
            CALL sp_update_cache_listingdate(NEW.`cache_id`);
        END IF;
        IF
            (SELECT `status` FROM `caches` WHERE `cache_id`=NEW.`cache_id`) != 5
            AND (SELECT `date_created` FROM `caches` WHERE `cache_id`=NEW.`cache_id`) < LEFT(NOW(),10)
        THEN
            INSERT IGNORE INTO `caches_attributes_modified`
                (`cache_id`, `attrib_id`, `date_modified`, `was_set`, `restored_by`)
                VALUES (NEW.`cache_id`, NEW.`attrib_id`, NOW(), 0, IFNULL(@restoredby,0));
        END IF;
        IF (
            NEW.`attrib_id`=6
            AND (SELECT `status` FROM `caches` WHERE `caches`.`cache_id`=NEW.`cache_id`) <= 2)
        THEN
            CALL sp_notify_new_cache(
                NEW.`cache_id`,
                (SELECT `longitude` FROM `caches` WHERE `caches`.`cache_id`=NEW.`cache_id`),
                (SELECT `latitude` FROM `caches` WHERE `caches`.`cache_id`=NEW.`cache_id`),
                2
            );
        END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheAttributesAfterUpdate` AFTER UPDATE ON `caches_attributes`
     FOR EACH ROW BEGIN
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            UPDATE `caches` SET `last_modified`=NOW() WHERE `cache_id`=NEW.`cache_id`;
            CALL sp_update_cache_listingdate(NEW.`cache_id`);
            IF OLD.`cache_id`!=NEW.`cache_id` THEN
                UPDATE `caches` SET `last_modified`=NOW() WHERE `cache_id`=OLD.`cache_id`;
                CALL sp_update_cache_listingdate(OLD.`cache_id`);
            END IF;
        END IF;
        IF
            NEW.`attrib_id`=6
            AND OLD.`attrib_id`<>6
            AND (SELECT `status` FROM `caches` WHERE `caches`.`cache_id`=NEW.`cache_id`) <= 2
        THEN
            CALL sp_notify_new_cache(
                NEW.`cache_id`,
                (SELECT `longitude` FROM `caches` WHERE `caches`.`cache_id`=NEW.`cache_id`),
                (SELECT `latitude` FROM `caches` WHERE `caches`.`cache_id`=NEW.`cache_id`),
                2
            );
        END IF;
        /* is not called, otherweise cache_attributes_modified would have to be updated,
           which would need an extension to restorecaches.php */
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `cacheAttributesAfterDelete` AFTER DELETE ON `caches_attributes`
     FOR EACH ROW BEGIN
        IF IFNULL(@deleting_cache,0)=0 THEN
            IF (ISNULL(@XMLSYNC) OR @XMLSYNC!=1) THEN
                UPDATE `caches` SET `last_modified`=NOW() WHERE `cache_id`=OLD.`cache_id`;
                CALL sp_update_cache_listingdate(OLD.`cache_id`);
            END IF;
            IF
                (SELECT `status` FROM `caches` WHERE `cache_id`=OLD.`cache_id`) != 5
                AND (SELECT `date_created` FROM `caches` WHERE `cache_id`=OLD.`cache_id`) < LEFT(NOW(),10)
            THEN
                INSERT IGNORE INTO `caches_attributes_modified` (`cache_id`, `attrib_id`, `date_modified`, `was_set`, `restored_by`) VALUES (OLD.`cache_id`, OLD.`attrib_id`, NOW(), 1, IFNULL(@restoredby,0));
            END IF;
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:49
