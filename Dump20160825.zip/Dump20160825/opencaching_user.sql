-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `node` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL COMMENT 'via Trigger (user)',
  `last_modified` datetime NOT NULL COMMENT 'via Trigger (user)',
  `last_login` date DEFAULT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(128) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `email_problems` int(10) NOT NULL DEFAULT '0',
  `first_email_problem` date DEFAULT NULL,
  `last_email_problem` datetime DEFAULT NULL,
  `mailing_problems` int(10) unsigned NOT NULL DEFAULT '0',
  `accept_mailing` tinyint(1) NOT NULL DEFAULT '1',
  `usermail_send_addr` tinyint(1) NOT NULL DEFAULT '0',
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `is_active_flag` tinyint(1) NOT NULL,
  `last_name` varchar(60) NOT NULL,
  `first_name` varchar(60) NOT NULL,
  `country` char(2) DEFAULT NULL,
  `pmr_flag` tinyint(1) NOT NULL,
  `new_pw_code` varchar(13) DEFAULT NULL,
  `new_pw_date` datetime DEFAULT NULL,
  `new_email_code` varchar(13) DEFAULT NULL,
  `new_email_date` datetime DEFAULT NULL,
  `new_email` varchar(60) DEFAULT NULL,
  `permanent_login_flag` tinyint(1) NOT NULL,
  `watchmail_mode` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `watchmail_hour` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `watchmail_nextmail` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'via cronjob',
  `watchmail_day` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `activation_code` varchar(13) NOT NULL,
  `statpic_logo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `statpic_text` varchar(30) NOT NULL DEFAULT 'Opencaching',
  `no_htmledit_flag` tinyint(1) NOT NULL DEFAULT '0',
  `notify_radius` int(10) unsigned NOT NULL DEFAULT '0',
  `notify_oconly` tinyint(1) NOT NULL DEFAULT '1',
  `language` char(2) DEFAULT NULL,
  `language_guessed` tinyint(1) NOT NULL DEFAULT '0',
  `domain` varchar(40) DEFAULT NULL,
  `admin` smallint(5) unsigned NOT NULL DEFAULT '0',
  `data_license` tinyint(1) NOT NULL DEFAULT '0',
  `description` longtext NOT NULL,
  `desc_htmledit` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  KEY `notify_radius` (`notify_radius`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `userBeforeInsert` BEFORE INSERT ON `user`
     FOR EACH ROW BEGIN
        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            SET NEW.`date_created`=NOW();
            SET NEW.`last_modified`=NOW();
        END IF;

        IF ISNULL(NEW.`uuid`) OR NEW.`uuid`='' THEN
            SET NEW.`uuid`=CREATE_UUID();
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `userBeforeUpdate` BEFORE UPDATE ON `user`
     FOR EACH ROW BEGIN
        /* dont overwrite date values while XML client is running */
        IF ISNULL(@XMLSYNC) OR @XMLSYNC!=1 THEN
            IF
                NEW.`user_id`!=OLD.`user_id`
                OR NEW.`uuid`!=BINARY OLD.`uuid`
                OR NEW.`node`!=OLD.`node`
                OR NEW.`date_created`!=OLD.`date_created`
                OR NEW.`username`!=BINARY OLD.`username`
                OR NEW.`country`!=BINARY OLD.`country`
                OR NEW.`pmr_flag`!=OLD.`pmr_flag`
                OR NEW.`description`!=BINARY OLD.`description`
            THEN
                SET NEW.`last_modified`=NOW();
            END IF;
        END IF;
        IF NEW.`email_problems`>0 AND NEW.`first_email_problem` IS NULL THEN
            SET NEW.`first_email_problem` = NEW.`last_email_problem`;
        ELSEIF NEW.`email_problems`=0 THEN
            SET NEW.`first_email_problem` = NULL;
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `userBeforeDelete` BEFORE DELETE ON `user`
     FOR EACH ROW BEGIN
        IF IFNULL(@allowdelete,0)=0 THEN
            CALL error_set_allowdelete_to_delete_users();
            /*
                There are exactly four reasons to delete a user record:

                1. account was not activated -> see user_delete.class.php
                2. Get rid of obsolete data on a test or developer machine.
                3. Get rid of a bad user record which was left over by a user creating bug.
                4. Remove replicated data from other nodes which are no longer useful.

                Do NOT delete a user record for any other reason!
            */
        ELSEIF IFNULL(@fastdelete,0) = 0 THEN
            /*
                use 'fastdelete' only to delete bulk data and if you are sure that
                you can handle all dependent data on your own
            */
            SET @deleting_user=1;

            DELETE FROM `cache_adoption` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_adoptions` WHERE `from_user_id`=OLD.user_id;
            DELETE FROM `cache_adoptions` WHERE `to_user_id`=OLD.user_id;
            DELETE FROM `cache_ignore` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_list_bookmarks` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_list_watches` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_lists` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_logs` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_logs_archived` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_rating` WHERE `user_id`=OLD.user_id;
            DELETE FROM `cache_reports` WHERE `userid`=OLD.user_id;  /* userid ! */
            DELETE FROM `cache_watches` WHERE `user_id`=OLD.user_id;
            DELETE FROM `caches` WHERE `user_id`=OLD.user_id;
            DELETE FROM `coordinates` WHERE `user_id`=OLD.user_id;
            /*
                no deletion from protocols `email_user` and from `logentries`
            */
            DELETE FROM `notify_waiting` WHERE `user_id`=OLD.user_id;
            DELETE FROM `queries` WHERE `user_id`=OLD.user_id;
            DELETE FROM `stat_cache_logs` WHERE `user_id`=OLD.user_id;
            DELETE FROM `stat_user` WHERE `user_id`=OLD.user_id;
            DELETE FROM `sys_repl_exclude` WHERE `user_id`=OLD.user_id;
            /*
                DELETE FROM `sys_sessions` WHERE `user_id`=OLD.user_id;
                Will be cleand up by cronjob, no index on user_id
            */
            DELETE FROM `user_delegates` WHERE `user_id`=OLD.user_id;
            DELETE FROM `user_options` WHERE `user_id`=OLD.user_id;
            DELETE FROM `user_statpic` WHERE `user_id`=OLD.user_id;
            DELETE FROM `watches_logqueue` WHERE `user_id`=OLD.user_id;
            DELETE FROM `watches_notified` WHERE `user_id`=OLD.user_id;
            DELETE FROM `watches_waiting` WHERE `user_id`=OLD.user_id;

            SET @deleting_user=0;

            /*
                'deleted_by' / 'restored_by' entries in archiving tables are not
                deleted to avoid creating inconsistencies there, as well as
                cache reports with this adminid and cache_status_modified entries
            */
        END IF;
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`opencaching`@`%`*/ /*!50003 TRIGGER `userAfterDelete` AFTER DELETE ON `user`
     FOR EACH ROW BEGIN
        INSERT IGNORE INTO `removed_objects` (`localId`, `uuid`, `type`, `node`) VALUES (OLD.`user_id`, OLD.`uuid`, 4, OLD.`node`);
     END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:51
