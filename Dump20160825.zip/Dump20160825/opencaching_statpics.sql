-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `statpics`
--

DROP TABLE IF EXISTS `statpics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statpics` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `tplpath` varchar(200) NOT NULL,
  `previewpath` varchar(200) NOT NULL,
  `description` varchar(80) NOT NULL,
  `trans_id` int(10) unsigned NOT NULL,
  `maxtextwidth` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COMMENT='static content';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statpics`
--

LOCK TABLES `statpics` WRITE;
/*!40000 ALTER TABLE `statpics` DISABLE KEYS */;
INSERT INTO `statpics` VALUES (1,'images/ocstats1.gif','images/ocstats1_prev.jpg','Default logo',1745,60),(2,'images/ocstats2.gif','images/ocstats2_prev.jpg','Alternative logo',1752,50),(3,'images/ocstats3.gif','images/ocstats3_prev.jpg','Alternative logo by nybbler',1747,50),(4,'images/ocstats4.gif','images/ocstats4_prev.jpg','Slimline',1753,50),(5,'images/ocstats5.gif','images/ocstats5_prev.jpg','Red logo, slimline',1754,50),(6,'images/ocstats4.gif','images/ocstats4a_prev.jpg','Slimline, without statistics',1755,50),(7,'images/ocstats5.gif','images/ocstats5a_prev.jpg','Slimline red, without statistics',1756,50),(8,'images/ocstats6.gif','images/ocstats6_prev.jpg','Round corners',1757,50),(9,'images/ocstats7.gif','images/ocstats7_prev.jpg','OC.de new',1821,60),(10,'images/ocstats8.gif','images/ocstats8_prev.jpg','OC.de new, slimline',1822,50),(11,'images/ocstats8.gif','images/ocstats8a_prev.jpg','OC.de new, without statistics',1823,50);
/*!40000 ALTER TABLE `statpics` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:51
