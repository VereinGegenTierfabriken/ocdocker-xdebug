-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache_type`
--

DROP TABLE IF EXISTS `cache_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_type` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `trans_id` int(10) NOT NULL,
  `ordinal` tinyint(3) unsigned NOT NULL,
  `short` varchar(10) NOT NULL,
  `de` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `icon_large` varchar(60) NOT NULL,
  `short2` varchar(15) NOT NULL,
  `short2_trans_id` int(10) NOT NULL,
  `kml_name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='static content';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_type`
--

LOCK TABLES `cache_type` WRITE;
/*!40000 ALTER TABLE `cache_type` DISABLE KEYS */;
INSERT INTO `cache_type` VALUES (1,'Unknown cache type',535,10,'Other','unbekannter Cachetyp','Unknown cache type','unknown.gif','Unknown',862,'unknown'),(2,'Traditional Cache',536,1,'Trad.','normaler Cache','Traditional Cache','traditional.gif','Traditional',1855,'tradi'),(3,'Multicache',514,3,'Multi','Multicache','Multicache','multi.gif','Multicache',514,'multi'),(4,'Virtual Cache',537,7,'Virt.','virtueller Cache','Virtual Cache','virtual.gif','Virtual',1857,'virtual'),(5,'Webcam Cache',538,8,'ICam.','Webcam-Cache','Webcam Cache','webcam.gif','Webcam',1572,'webcam'),(6,'Event Cache',539,9,'Event','Event-Cache','Event Cache','event.gif','Event',1859,'event'),(7,'Quiz Cache',518,4,'Quiz','Rätselcache','Quiz Cache','mystery.gif','Quiz',1860,'mystery'),(8,'Math/Physics Cache',540,5,'Math','Mathe-/Physikcache','Math/Physics Cache','mathe.gif','Math/Physics',1861,'mathe'),(9,'Moving Cache',541,6,'Moving','beweglicher Cache','Moving Cache','moving.gif','Moving',1862,'moving'),(10,'Drive-in Cache',542,2,'Driv.','Drive-In-Cache','Drive-in Cache','drivein.gif','Drive-in',1863,'drivein');
/*!40000 ALTER TABLE `cache_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:50
