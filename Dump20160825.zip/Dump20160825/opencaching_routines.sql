-- MySQL dump 10.13  Distrib 5.7.13, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: opencaching
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb7u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'opencaching'
--

--
-- Dumping routines for database 'opencaching'
--
/*!50003 DROP FUNCTION IF EXISTS `CREATE_UUID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `CREATE_UUID`() RETURNS varchar(36) CHARSET utf8
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
        SET @LAST_UUID = UUID();
        RETURN @LAST_UUID;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `dbsvTriggerVersion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `dbsvTriggerVersion`() RETURNS int(11)
RETURN '0' ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `DECTOWP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `DECTOWP`(wp INT, prefix VARCHAR(2)) RETURNS varchar(7) CHARSET utf8
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
        -- all used chars in waypoint, in their ascending order
        DECLARE WP_ORDER CHAR(36) DEFAULT '0123456789ABCDEF';
        -- list of base 36 chars in their ascending order
        DECLARE B36_ORDER CHAR(36) DEFAULT '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        -- base 36 value of the decimal waypoint value
        DECLARE B36_VALUE VARCHAR(5);
        -- will contain the waypoint value, without prefix
        DECLARE WP_VALUE CHAR(5) DEFAULT '';
        -- loop counter
        DECLARE B36_POS INT DEFAULT 1;
        -- index of a char in WP_ORDER/B36_ORDER
        DECLARE B36_ORDER_INDEX INT;

        -- validate input
        IF ISNULL(wp) OR ISNULL(prefix) THEN
            RETURN '';
        END IF;
        IF LENGTH(prefix) != 2 OR wp=0 THEN
            RETURN '';
        END IF;

        -- convert the decimal waypoint value to base 36
        SET B36_VALUE = CONV(wp, 10, LENGTH(WP_ORDER));

        -- replace each char in B36_VALUE with the equivalent wp-char
        REPEAT
            SET B36_ORDER_INDEX = LOCATE(SUBSTRING(B36_VALUE, B36_POS, 1), B36_ORDER);
            IF B36_ORDER_INDEX = 0 THEN
                RETURN '';
            END IF;
            SET WP_VALUE = CONCAT(WP_VALUE, SUBSTRING(WP_ORDER, B36_ORDER_INDEX, 1));
            SET B36_POS = B36_POS + 1;
        UNTIL B36_POS>LENGTH(B36_VALUE) END REPEAT;

        IF LENGTH(WP_VALUE)<4 THEN
            RETURN CONCAT(prefix, RIGHT(CONCAT('0000', WP_VALUE), 4));
        ELSE
            RETURN CONCAT(prefix, WP_VALUE);
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GET_LAST_UUID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `GET_LAST_UUID`() RETURNS varchar(36) CHARSET utf8
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
        RETURN @LAST_UUID;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `PREFERED_LANG` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `PREFERED_LANG`(sExistingTokens VARCHAR(60), sPreferedTokens VARCHAR(60)) RETURNS char(2) CHARSET utf8
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
        DECLARE nPreferedIndex INT DEFAULT 1;
        DECLARE sPrefered CHAR(2) DEFAULT '';
        DECLARE sLastPrefered CHAR(2) DEFAULT '';
        DECLARE nPos INT DEFAULT 0;

        IF ISNULL(sExistingTokens) THEN
            RETURN NULL;
        END IF;

        SET sExistingTokens = CONCAT(',', sExistingTokens, ',');

        SET sPrefered = SUBSTRING_INDEX(SUBSTRING_INDEX(sPreferedTokens, ',', nPreferedIndex), ',', -1);
        pl: LOOP
            IF sPrefered = sLastPrefered THEN
                LEAVE pl;
            END IF;

            SET nPos = INSTR(sExistingTokens, CONCAT(',', sPrefered, ','));
            IF nPos!=0 THEN
                RETURN sPrefered;
            END IF;

            SET sLastPrefered = sPrefered;
            SET nPreferedIndex = nPreferedIndex + 1;
            SET sPrefered = SUBSTRING_INDEX(SUBSTRING_INDEX(sPreferedTokens, ',', nPreferedIndex), ',', -1);
        END LOOP pl;

        SET sPrefered = SUBSTRING_INDEX(SUBSTRING_INDEX(sExistingTokens, ',', 2), ',', -1);
        IF sPrefered = '' THEN
            RETURN NULL;
        ELSE
            RETURN sPrefered;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `STRIP_LEADING_NONALNUM` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `STRIP_LEADING_NONALNUM`(s VARCHAR(255)) RETURNS varchar(255) CHARSET utf8
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
        DECLARE n INT(10) DEFAULT 1;
        WHILE n <= LENGTH(s) AND SUBSTR(s,n,1) REGEXP '[[:punct:][:space:]]' DO
            SET n = n + 1;
        END WHILE;
        RETURN SUBSTR(s,n);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `WPTODEC` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` FUNCTION `WPTODEC`(wp VARCHAR(7), prefix VARCHAR(2)) RETURNS int(11)
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
        -- all used chars in waypoint, in their ascending order
        DECLARE WP_ORDER CHAR(36) DEFAULT '0123456789ABCDEF';
        -- list of base 36 chars in their ascending order
        DECLARE B36_ORDER CHAR(36) DEFAULT '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        -- will contain the waypoint value, without prefix
        DECLARE WP_VALUE CHAR(5) DEFAULT '00000';
        -- will contain WP_VALUE where all chars replaced by their equivalents in B36_ORDER
        DECLARE B36_VALUE CHAR(5) DEFAULT '';
        -- loop counter
        DECLARE WP_POS INT DEFAULT 1;
        -- index of a char in WP_ORDER/B36_ORDER
        DECLARE WP_ORDER_INDEX INT;

        -- validate input
        IF ISNULL(wp) OR ISNULL(prefix) THEN
            RETURN 0;
        END IF;
        IF LENGTH(prefix) != 2 OR LENGTH(wp)<3 OR LENGTH(wp)>7 THEN
            RETURN 0;
        END IF;
        IF LEFT(wp, 2) != prefix THEN
            RETURN 0;
        END IF;

        -- get waypoint value with exactly 5 digits
        SET WP_VALUE = RIGHT(CONCAT('00000', SUBSTRING(wp, 3)), 5);

        -- replace each char in WP_VALUE with the equivalent base 36 char
        REPEAT
            SET WP_ORDER_INDEX = LOCATE(SUBSTRING(WP_VALUE, WP_POS, 1), WP_ORDER);
            IF WP_ORDER_INDEX = 0 THEN
                RETURN 0;
            END IF;
            SET B36_VALUE = CONCAT(B36_VALUE, SUBSTRING(B36_ORDER, WP_ORDER_INDEX, 1));
            SET WP_POS = WP_POS + 1;
        UNTIL WP_POS>5 END REPEAT;

        -- now use CONV() to convert from base 36 system to decimal
        RETURN CONV(B36_VALUE, LENGTH(WP_ORDER), 10);
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_notify_new_cache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_notify_new_cache`(
        IN nCacheId INT(10) UNSIGNED,
        IN nLongitude DOUBLE,
        IN nLatitude DOUBLE,
        IN nType INT(1)
     )
BEGIN
        /* type 1 = new cache, 2 = new OConly attribute */
        INSERT IGNORE INTO `notify_waiting` (`cache_id`, `user_id`, `type`)
            SELECT nCacheId, `user`.`user_id`, nType /* notify_new_cache */
            FROM `user`
            /* Throttle email sending after undeliverable mails. See also runwatch.php. */
            WHERE
                (`email_problems` = 0
                 OR DATEDIFF(NOW(),`last_email_problem`) > 1 + DATEDIFF(`last_email_problem`, `first_email_problem`)
                )
                AND (nType=1 OR `user`.`notify_oconly`)
                AND `user`.`latitude`+`user`.`longitude` <> 0
                AND `user`.`notify_radius`>0
                AND (acos(cos((90-nLatitude) * 3.14159 / 180) * cos((90-`user`.`latitude`) * 3.14159 / 180) + sin((90-nLatitude) * 3.14159 / 180) * sin((90-`user`.`latitude`) * 3.14159 / 180) * cos((nLongitude-`user`.`longitude`) * 3.14159 / 180)) * 6370)
                    <= `user`.`notify_radius`;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_refreshall_statpic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_refreshall_statpic`()
BEGIN
        DELETE FROM `user_statpic`;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_refresh_statpic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_refresh_statpic`(IN nUserId INT(10) UNSIGNED)
BEGIN
        DELETE FROM `user_statpic` WHERE `user_id`=nUserId;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_touch_cache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_touch_cache`(IN nCacheId INT(10) UNSIGNED, IN bUpdateCacheRecord BOOL)
BEGIN
        IF bUpdateCacheRecord = TRUE AND IFNULL(@deleting_cache,0)=0 THEN
            UPDATE `caches` SET `last_modified`=NOW() WHERE `cache_id`=nCacheId;
        END IF;

        /* This is a hack for the XML interface which delivers cache-related records
         * like descriptions and pictures only depending on their last_modified date.
         * Data may not have been deliverd or stored somewhere depending on the cache
         * status, so when status changes, all has to be sent (again) via XML.
         */

        UPDATE `cache_desc` SET `last_modified`=NOW() WHERE `cache_id`=nCacheId;
        UPDATE `cache_logs` SET `last_modified`=NOW() WHERE `cache_id`=nCacheId;
        UPDATE `coordinates` SET `last_modified`=NOW() WHERE `cache_id`=nCacheId AND `type`=1;
        UPDATE `pictures` SET `last_modified`=NOW() WHERE `object_type`=2 AND `object_id`=nCacheId;
        SET @dont_update_logdate=TRUE;  /* avoid access collision to cache_logs table */

        UPDATE `pictures`, `cache_logs`
        SET `pictures`.`last_modified`=NOW()
        WHERE
            `pictures`.`object_type`=1
            AND `pictures`.`object_id`=`cache_logs`.`id`
            AND `cache_logs`.`cache_id`=nCacheId;

        SET @dont_update_logdate=FALSE;
        UPDATE `mp3` SET `last_modified`=NOW() WHERE `object_id`=nCacheId;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_cachelist_counts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_cachelist_counts`(OUT nModified INT)
BEGIN
        UPDATE `stat_cache_lists`
        SET `entries` =
            (SELECT COUNT(*)
             FROM `cache_list_items`
             WHERE `cache_list_items`.`cache_list_id`=`stat_cache_lists`.`cache_list_id`
            );

        SET nModified = ROW_COUNT();

        UPDATE `stat_cache_lists`
        SET `watchers`=
            (SELECT COUNT(*) FROM `cache_list_watches`
             WHERE `cache_list_watches`.`cache_list_id`=`stat_cache_lists`.`cache_list_id`
            );

        SET nModified = nModified + ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_cachelog_logdates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_cachelog_logdates`(OUT nModified INT)
BEGIN
        /* log_last_modified can be greater then all the other dates, if a picture was deleted.
           Therefore it should generally not be set back to an earlier datetime! */
        
        UPDATE `cache_logs` SET `log_last_modified` =
            GREATEST(
                `log_last_modified`,
                GREATEST(
                    `last_modified`,
                    IFNULL(
                        (SELECT MAX(`last_modified`)
                         FROM `pictures`
                         WHERE `pictures`.`object_type`=1 AND `pictures`.`object_id` = `cache_logs`.`id`
                        ),
                        '0'
                    )
                )
            );
        SET nModified = ROW_COUNT();

        UPDATE `cache_logs_archived`
        SET `log_last_modified` = GREATEST(`last_modified`, `log_last_modified`);

        SET nModified = nModified + ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_cachelog_picturestat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_cachelog_picturestat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        /* cache_logs.picture */
        UPDATE
             `cache_logs`,
             (SELECT `object_id` AS `log_id`, COUNT(*) AS `count`
              FROM `pictures`
              WHERE `object_type`=1
              GROUP BY `object_type`, `object_id`
             ) AS `tblPictures`
        SET `cache_logs`.`picture`=`tblPictures`.`count`
        WHERE `cache_logs`.`id`=`tblPictures`.`log_id`;
    
        SET nModified = nModified + ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_caches_descLanguages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_caches_descLanguages`(OUT nModified INT)
BEGIN
        UPDATE `caches`,
               (SELECT `cache_id`,
                GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `dl`
                FROM `cache_desc`
                GROUP BY `cache_id`
               ) AS `tbl`
        SET
            `caches`.`desc_languages`=`tbl`.`dl`,
            `caches`.`default_desclang`=PREFERED_LANG(`tbl`.`dl`, 'DE,EN')
        WHERE `caches`.`cache_id`=`tbl`.`cache_id`;
        
        SET nModified = ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_cache_listingdates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_cache_listingdates`(OUT nModified INT)
BEGIN
         /* listing_last_modified can be greater then all the other dates, if a description,
            a coordinate or a picture was deleted. Therefore it should generally not be
            set back to an earlier datetime! */

         UPDATE `caches` SET `listing_last_modified` =
            GREATEST(
                `listing_last_modified`,
                GREATEST(
                    `last_modified`,
                    GREATEST(
                        IFNULL(
                            (SELECT MAX(`last_modified`)
                             FROM `cache_desc`
                             WHERE `cache_desc`.`cache_id`=`caches`.`cache_id`
                            ),
                            '0'),
                        GREATEST(
                            IFNULL(
                                (SELECT MAX(`last_modified`)
                                 FROM `coordinates`
                                 WHERE `coordinates`.`type`=1 AND `coordinates`.`cache_id`=`caches`.`cache_id`
                                ),
                                '0'
                            ),
                            IFNULL(
                                (SELECT MAX(`last_modified`)
                                 FROM `pictures`
                                 WHERE `pictures`.`object_type`=2 AND `pictures`.`object_id` = `caches`.`cache_id`
                                ),
                                '0'
                            )
                        )
                    )
                )
            );
        SET nModified = ROW_COUNT();
      END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_cache_picturestat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_cache_picturestat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        INSERT IGNORE INTO `stat_caches` (`cache_id`)
            SELECT DISTINCT `object_id` AS `cache_id` FROM `pictures` WHERE `object_type`=2;

        /* stat_caches.picture */
        UPDATE
             `stat_caches`,
             (SELECT `object_id` AS `cache_id`, COUNT(*) AS `count`
              FROM `pictures`
              WHERE `object_type`=2
              GROUP BY `object_type`, `object_id`
             ) AS `tblPictures`
        SET `stat_caches`.`picture`=`tblPictures`.`count`
        WHERE `stat_caches`.`cache_id`=`tblPictures`.`cache_id`;
        SET nModified = nModified + ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_hiddenstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_hiddenstat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        INSERT IGNORE INTO `stat_user` (`user_id`)
        SELECT `user_id`
        FROM `caches`
        GROUP BY `user_id`;

        /* stat_caches.hidden */
        UPDATE
            `stat_user`,
            (SELECT `user_id`, COUNT(*) AS `count`
             FROM `caches`
             INNER JOIN `cache_status`
                ON `cache_status`.`id`=`caches`.`status`
                AND `allow_user_view`=1 GROUP BY `user_id`
            ) AS `tblHidden`
        SET `stat_user`.`hidden`=`tblHidden`.`count`
        WHERE `stat_user`.`user_id`=`tblHidden`.`user_id`;

        SET nModified = nModified + ROW_COUNT();

        CALL sp_refreshall_statpic();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_ignorestat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_ignorestat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        INSERT IGNORE INTO `stat_caches` (`cache_id`)
            SELECT `cache_id` FROM `cache_ignore` GROUP BY `cache_id`;

        /* stat_caches.ignore */
        UPDATE
            `stat_caches`,
            (SELECT `cache_id`, COUNT(*) AS `count`
             FROM `cache_ignore`
             GROUP BY `cache_id`
            ) AS `tblIgnore`
        SET `stat_caches`.`ignore`=`tblIgnore`.`count`
        WHERE `stat_caches`.`cache_id`=`tblIgnore`.`cache_id`;
       
        SET nModified = nModified + ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_logstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_logstat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        INSERT IGNORE INTO `stat_user` (`user_id`)
            SELECT `user_id` FROM `cache_logs` GROUP BY `user_id`;
        INSERT IGNORE INTO `stat_caches` (`cache_id`)
            SELECT `cache_id` FROM `cache_logs` GROUP BY `cache_id`;
        INSERT IGNORE INTO `stat_cache_logs` (`cache_id`, `user_id`)
            SELECT `cache_id`, `user_id` FROM `cache_logs`;

        /* This implementation is less performant than the previouse code (up to ~ commit 4ed7ee0),
            but the old did not update any values to zero - these entries were ignored!
            -- following 2013-05-12 */

        /* stat_caches */
        UPDATE `stat_caches`
        SET
            `found` = (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (1, 7) AND `cache_logs`.`cache_id` = `stat_caches`.`cache_id`),
            `last_found` = (SELECT MAX(`date`) FROM `cache_logs` WHERE `type` IN (1, 7) AND `cache_logs`.`cache_id` = `stat_caches`.`cache_id`),
            `notfound`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (2) AND `cache_logs`.`cache_id` = `stat_caches`.`cache_id`),
            `note`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (3) AND `cache_logs`.`cache_id` = `stat_caches`.`cache_id`),
            `will_attend`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (8) AND `cache_logs`.`cache_id` = `stat_caches`.`cache_id`),
            `maintenance`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (9,10,11,13,14) AND `cache_logs`.`cache_id` = `stat_caches`.`cache_id`);

        /* stat_cache_logs */
        UPDATE `stat_cache_logs`
        SET
            `found` = (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (1, 7) AND `cache_logs`.`cache_id` = `stat_cache_logs`.`cache_id` AND `cache_logs`.`user_id` = `stat_cache_logs`.`user_id`),
            `notfound`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (2) AND `cache_logs`.`cache_id` = `stat_cache_logs`.`cache_id` AND `cache_logs`.`user_id` = `stat_cache_logs`.`user_id`),
            `note`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (3) AND `cache_logs`.`cache_id` = `stat_cache_logs`.`cache_id` AND `cache_logs`.`user_id` = `stat_cache_logs`.`user_id`),
            `will_attend`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (8) AND `cache_logs`.`cache_id` = `stat_cache_logs`.`cache_id` AND `cache_logs`.`user_id` = `stat_cache_logs`.`user_id`),
            `maintenance`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (9,10,11,13,14) AND `cache_logs`.`cache_id` = `stat_cache_logs`.`cache_id` AND `cache_logs`.`user_id` = `stat_cache_logs`.`user_id`);

        SET nModified = nModified + ROW_COUNT();

        /* stat_user */
        UPDATE `stat_user`
        SET
            `found` = (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (1, 7) AND `cache_logs`.`user_id` = `stat_user`.`user_id`),
            `notfound`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (2) AND `cache_logs`.`user_id` = `stat_user`.`user_id`),
            `note`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (3) AND `cache_logs`.`user_id` = `stat_user`.`user_id`),
            `will_attend`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (8) AND `cache_logs`.`user_id` = `stat_user`.`user_id`),
            `maintenance`= (SELECT COUNT(*) FROM `cache_logs` WHERE `type` IN (9,10,11,13,14) AND `cache_logs`.`user_id` = `stat_user`.`user_id`);

        SET nModified = nModified + ROW_COUNT();

        CALL sp_refreshall_statpic();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_rating_dates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_rating_dates`(OUT nModified INT)
BEGIN
        UPDATE `cache_rating`
        SET `rating_date` =
            (SELECT `date` FROM `cache_logs`
             WHERE
                `cache_logs`.`cache_id`=`cache_rating`.`cache_id`
                AND `cache_logs`.`user_id`=`cache_rating`.`user_id`
                AND `cache_logs`.`type` IN (1,7)
             ORDER BY `date` LIMIT 1
            )
        WHERE
            (SELECT COUNT(*) FROM `cache_logs`
             WHERE
                `cache_logs`.`cache_id`=`cache_rating`.`cache_id`
                AND `cache_logs`.`user_id`=`cache_rating`.`user_id`
                AND `cache_logs`.`date`=`cache_rating`.`rating_date`
                AND `type` IN (1,7)
            ) = 0;
        /* will set rating_date to 0000-00...:00 for orphan records */

        SET nModified = ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_topratingstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_topratingstat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        INSERT IGNORE INTO `stat_caches` (`cache_id`)
        SELECT `cache_id`
        FROM `cache_rating` GROUP BY `cache_id`;

        UPDATE `stat_caches`
        LEFT JOIN `cache_rating` ON `stat_caches`.`cache_id`=`cache_rating`.`cache_id`
        SET `stat_caches`.`toprating`=0
        WHERE ISNULL(`cache_rating`.`cache_id`);

        /* stat_caches.toprating */
        UPDATE
            `stat_caches`,
            (SELECT `cache_id`, COUNT(*) AS `count`
             FROM `cache_rating`
             GROUP BY `cache_id`
            ) AS `tblRating`
        SET `stat_caches`.`toprating`=`tblRating`.`count`
        WHERE `stat_caches`.`cache_id`=`tblRating`.`cache_id`;

        SET nModified = nModified + ROW_COUNT();
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_updateall_watchstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_updateall_watchstat`(OUT nModified INT)
BEGIN
        SET nModified=0;

        INSERT IGNORE INTO `stat_caches` (`cache_id`)
            SELECT DISTINCT `cache_id` FROM `cache_watches`
            UNION
            SELECT DISTINCT `cache_id` FROM `cache_list_items`
            WHERE `cache_list_items`.`cache_list_id` IN (SELECT `cache_list_id` FROM `cache_list_watches`);

        /* initialize temp watch stats with 0 */
        DROP TEMPORARY TABLE IF EXISTS `tmp_watchstat`;
        CREATE TEMPORARY TABLE `tmp_watchstat` ENGINE=MEMORY
            (SELECT `cache_id`, 0 AS `watch` FROM `stat_caches`);
        ALTER TABLE `tmp_watchstat` ADD PRIMARY KEY (`cache_id`);

        /* calculate temp stats for all watches caches (no effect for unwatched) */
        UPDATE
            `tmp_watchstat`,
            (SELECT `cache_id`, COUNT(*) AS `count`
             FROM
                (SELECT `cache_id`, `user_id` FROM `cache_watches`
                 UNION
                 SELECT `cache_id`, `user_id` FROM `cache_list_items`, `cache_list_watches`
                 WHERE `cache_list_items`.`cache_list_id` = `cache_list_watches`.`cache_list_id`
                ) `ws`
             GROUP BY `cache_id`
            ) `users_watching_caches`
            SET `tmp_watchstat`.`watch` = `users_watching_caches`.`count`
            WHERE `tmp_watchstat`.`cache_id` = `users_watching_caches`.`cache_id`;

        /* transfer temp data to stat_caches */
        UPDATE `stat_caches`, (SELECT * FROM `tmp_watchstat`) AS `ws`
        SET `stat_caches`.`watch` = `ws`.`watch`
        WHERE `stat_caches`.`cache_id` = `ws`.`cache_id`;

        SET nModified = nModified + ROW_COUNT();

        DROP TEMPORARY TABLE `tmp_watchstat`;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_cachelog_picturestat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_cachelog_picturestat`(IN nLogId INT, IN bRemoved BOOLEAN)
BEGIN
        DECLARE nPicture INT DEFAULT 1;
        IF IFNULL(@deleting_log,0)=0 THEN
            IF bRemoved = TRUE THEN
                SET nPicture = -1;
            END IF;

            UPDATE `cache_logs`
            SET `cache_logs`.`picture` =
                IF(`cache_logs`.`picture`+nPicture>0, `cache_logs`.`picture`+nPicture, 0)
            WHERE `cache_logs`.`id`=nLogId;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_cachelog_rating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_cachelog_rating`(IN nCacheId INT, IN nUserID INT, IN dRatingDate DATETIME)
BEGIN
        IF (ISNULL(@XMLSYNC) OR @XMLSYNC!=1) AND IFNULL(@deleting_cache,0)=0 THEN
            UPDATE `cache_logs`
            SET `last_modified`=NOW()
            WHERE
                `cache_logs`.`cache_id`=nCacheId
                AND `cache_logs`.`user_id`=nUserID
                AND `cache_logs`.`date`=dRatingDate;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_caches_descLanguages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_caches_descLanguages`(IN nCacheId INT(10) UNSIGNED)
BEGIN
        DECLARE dl VARCHAR(60);

        IF IFNULL(@deleting_cache,0)=0 THEN
            SELECT GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') INTO dl
            FROM `cache_desc`
            WHERE `cache_id`=nCacheId
            GROUP BY `cache_id`;
            
            UPDATE `caches`
            SET `desc_languages`=dl, default_desclang=PREFERED_LANG(dl, 'DE,EN')
            WHERE `cache_id`=nCacheId
            LIMIT 1;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_cache_listingdate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_cache_listingdate`(IN nCacheId INT(10) UNSIGNED)
BEGIN
        IF (ISNULL(@XMLSYNC) OR @XMLSYNC!=1)
            AND IFNULL(@dont_update_listingdate,0)=0
            AND IFNULL(@deleting_cache,0)=0 THEN
            /* @dont_update_listingdate avoids illegal update recursions in caches table, e.g.
             * update caches.status -> sp_touch_cache -> update coordinates
             * -> sp_update_cache_listingdate -> update caches
             */
            UPDATE `caches` SET `listing_last_modified`=NOW() WHERE `cache_id`=nCacheId LIMIT 1;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_cache_picturestat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_cache_picturestat`(IN nCacheId INT, IN bRemoved BOOLEAN)
BEGIN
        DECLARE nPicture INT DEFAULT 1;
        IF IFNULL(@deleting_cache,0)=0 THEN
            IF bRemoved = TRUE THEN
                SET nPicture = -1;
            END IF;

            UPDATE `stat_caches`
            SET `stat_caches`.`picture` =
                IF(`stat_caches`.`picture`+nPicture>0, `stat_caches`.`picture`+nPicture, 0)
            WHERE `stat_caches`.`cache_id`=nCacheId;

            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_caches` (`cache_id`, `picture`)
                VALUES (nCacheId, IF(nPicture>0, nPicture, 0));
            END IF;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_hiddenstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_hiddenstat`(IN nUserId INT, IN iStatus INT, IN bRemoved BOOLEAN)
BEGIN
        DECLARE nHidden INT DEFAULT 1;
        IF IFNULL(@deleting_user,0)=0 THEN
            IF (SELECT `allow_user_view` FROM `cache_status` WHERE `id`=iStatus) THEN
                IF bRemoved = TRUE THEN
                    SET nHidden = -1;
                END IF;

                UPDATE `stat_user`
                SET `stat_user`.`hidden` = IF(`stat_user`.`hidden`+nHidden>0, `stat_user`.`hidden`+nHidden, 0)
                WHERE `stat_user`.`user_id`=nUserId;
               
                IF ROW_COUNT() = 0 THEN
                    INSERT IGNORE INTO `stat_user` (`user_id`, `hidden`)
                    VALUES (nUserId, IF(nHidden>0, nHidden, 0));
                END IF;

                CALL sp_refresh_statpic(nUserId);
            END IF;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_ignorestat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_ignorestat`(IN nCacheId INT, IN bRemoved BOOLEAN)
BEGIN
        DECLARE nIgnore INT DEFAULT 1;
        IF IFNULL(@deleting_cache,0)=0 THEN
            IF bRemoved = TRUE THEN
                SET nIgnore = -1;
            END IF;
            
            UPDATE `stat_caches`
            SET `stat_caches`.`ignore` =
                IF(`stat_caches`.`ignore`+nIgnore>0, `stat_caches`.`ignore`+nIgnore, 0)
            WHERE `stat_caches`.`cache_id`=nCacheId;

            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_caches` (`cache_id`, `ignore`)
                VALUES (nCacheId, IF(nIgnore>0, nIgnore, 0));
            END IF;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_list_watchstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_list_watchstat`(IN nCachelistId INT)
BEGIN
        DECLARE done INT DEFAULT 0;
        DECLARE cacheid INT DEFAULT 0;
        DECLARE cur1 CURSOR FOR
            SELECT `cache_id` FROM `cache_list_items` WHERE `cache_list_id` = nCachelistId;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
        
        OPEN cur1;
        REPEAT
            FETCH cur1 INTO cacheid;
            IF NOT done THEN
                CALL sp_update_watchstat(cacheid);
            END IF;
        UNTIL done END REPEAT;
        CLOSE cur1;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_logstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_logstat`(
        IN nCacheId INT(10) UNSIGNED,
        IN nUserId INT(10) UNSIGNED,
        IN nLogType INT,
        IN bLogRemoved BOOLEAN
     )
BEGIN
        DECLARE nFound INT DEFAULT 0;
        DECLARE nNotFound INT DEFAULT 0;
        DECLARE nNote INT DEFAULT 0;
        DECLARE nWillAttend INT DEFAULT 0;
        DECLARE nMaintenance INT DEFAULT 0;
        DECLARE nDate DATE DEFAULT NULL;

        IF nLogType = 1 THEN SET nFound=1; END IF;
        IF nLogType = 2 THEN SET nNotFound=1; END IF;
        IF nLogType = 3 THEN SET nNote=1; END IF;
        IF nLogType = 7 THEN SET nFound=1; END IF;
        IF nLogType = 8 THEN SET nWillAttend=1; END IF;
        IF nLogType IN (9,10,11,13,14) THEN SET nMaintenance=1; END IF;

        IF bLogRemoved = TRUE THEN
            SET nFound = -nFound;
            SET nNotFound = -nNotFound;
            SET nNote = -nNote;
            SET nWillAttend = -nWillAttend;
            SET nMaintenance = -nMaintenance;
        END IF;

        IF IFNULL(@deleting_cache,0)=0 THEN
            UPDATE `stat_cache_logs`
            SET
                `found` = IF(`found`+nFound>0, `found`+nFound, 0),
                `notfound` = IF(`notfound`+nNotFound>0, `notfound`+nNotFound, 0),
                `note` = IF(`note`+nNote>0, `note`+nNote, 0),
                `will_attend` = IF(`will_attend`+nWillAttend>0, `will_attend`+nWillAttend, 0),
                `maintenance` = IF(`maintenance`+nMaintenance>0, `maintenance`+nMaintenance, 0)
            WHERE
                `cache_id`=nCacheId
                AND `user_id`=nUserId;

            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_cache_logs`
                    (`cache_id`, `user_id`, `found`, `notfound`, `note`, `will_attend`, `maintenance`)
                VALUES (
                    nCacheId,
                    nUserId,
                    IF(nFound>0, nFound, 0),
                    IF(nNotFound>0, nNotFound, 0),
                    IF(nNote>0, nNote, 0),
                    IF(nWillAttend>0, nWillAttend, 0),
                    IF(nMaintenance>0, nMaintenance, 0)
                );
            END IF;

            UPDATE `stat_caches`
            SET
                `found` = IF(`found`+nFound>0, `found`+nFound, 0),
                `notfound` = IF(`notfound`+nNotFound>0, `notfound`+nNotFound, 0),
                `note` = IF(`note`+nNote>0, `note`+nNote, 0),
                `will_attend` = IF(`will_attend`+nWillAttend>0, `will_attend`+nWillAttend, 0),
                `maintenance` = IF(`maintenance`+nMaintenance>0, `maintenance`+nMaintenance, 0)
            WHERE `cache_id`=nCacheId;

            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_caches`
                    (`cache_id`, `found`, `notfound`, `note`, `will_attend`, `maintenance`)
                VALUES (
                    nCacheId,
                    IF(nFound>0, nFound, 0),
                    IF(nNotFound>0, nNotFound, 0),
                    IF(nNote>0, nNote, 0),
                    IF(nWillAttend>0, nWillAttend, 0),
                    IF(nMaintenance>0, nMaintenance, 0)
                );
            END IF;

            IF nFound!=0 THEN
                SELECT LEFT(`date`,10) INTO nDate
                FROM `cache_logs`
                WHERE `cache_id`=nCacheId AND `type` IN (1, 7)
                ORDER BY `date` DESC
                LIMIT 1;
                
                UPDATE `stat_caches`
                SET `last_found`=nDate
                WHERE `cache_id`=nCacheId;
            END IF;
            
            UPDATE `caches`
            SET
                `needs_maintenance` =
                    (SELECT GREATEST(0,`needs_maintenance`-1)
                     FROM `cache_logs`
                     WHERE
                        `cache_logs`.`cache_id`=nCacheID
                        AND (`cache_logs`.`needs_maintenance`>0 OR `cache_logs`.`type` In (9,13,14))
                        ORDER BY `order_date` DESC, `date_created` DESC, `id` DESC
                        LIMIT 1
                    ),
                `listing_outdated` =
                    (SELECT GREATEST(0,`listing_outdated`-1)
                     FROM `cache_logs`
                     WHERE
                        `cache_logs`.`cache_id`=nCacheID
                        AND (`cache_logs`.`listing_outdated`>0 OR `cache_logs`.`type` In (9,13,14))
                     ORDER BY `order_date` DESC, `date_created` DESC, `id` DESC
                     LIMIT 1
                    )
                /* same sorting order as in caches::getListingOutdatedLogUrl() */
            WHERE `caches`.`cache_id`=nCacheId;
        END IF;

        IF IFNULL(@deleting_user,0)=0 THEN
            UPDATE `stat_user`
            SET
                `found` = IF(`found`+nFound>0, `found`+nFound, 0),
                `notfound` = IF(`notfound`+nNotFound>0, `notfound`+nNotFound, 0),
                `note` = IF(`note`+nNote>0, `note`+nNote, 0),
                `will_attend` = IF(`will_attend`+nWillAttend>0, `will_attend`+nWillAttend, 0),
                `maintenance` = IF(`maintenance`+nMaintenance>0, `maintenance`+nMaintenance, 0)
            WHERE `user_id`=nUserId;

            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_user`
                    (`user_id`, `found`, `notfound`, `note`, `will_attend`, `maintenance`)
                VALUES (
                    nUserId,
                    IF(nFound>0, nFound, 0),
                    IF(nNotFound>0, nNotFound, 0),
                    IF(nNote>0, nNote, 0),
                    IF(nWillAttend>0, nWillAttend, 0),
                    IF(nMaintenance>0, nMaintenance, 0)
                );
            END IF;

            CALL sp_refresh_statpic(nUserId);
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_topratingstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_topratingstat`(IN nCacheId INT, IN bRemoved BOOLEAN)
BEGIN
        DECLARE nTopRating INT DEFAULT 1;
        IF IFNULL(@deleting_cache,0)=0 THEN
            IF bRemoved = TRUE THEN
                SET nTopRating = -1;
            END IF;

            UPDATE `stat_caches`
            SET `stat_caches`.`toprating` =
                IF(`stat_caches`.`toprating`+nTopRating>0, `stat_caches`.`toprating`+nTopRating, 0)
            WHERE `stat_caches`.`cache_id`=nCacheId;
            
            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_caches` (`cache_id`, `toprating`)
                VALUES (nCacheId, IF(nTopRating>0, nTopRating, 0));
            END IF;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_watchstat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`opencaching`@`%` PROCEDURE `sp_update_watchstat`(IN nCacheId INT)
BEGIN
        DECLARE nWatches INT DEFAULT 0;
        IF IFNULL(@deleting_cache,0)=0 THEN
            SET nWatches =
                (SELECT COUNT(*)
                 FROM
                    (SELECT `cache_list_watches`.`user_id`
                     FROM `cache_list_watches`, `cache_lists`, `cache_list_items`
                     WHERE
                        `cache_list_items`.`cache_id`=nCacheId
                        AND `cache_lists`.`id`=`cache_list_items`.`cache_list_id`
                        AND `cache_list_watches`.`cache_list_id`=`cache_lists`.`id`
                     UNION   /* UNION discards duplicates */
                     SELECT `user_id`
                     FROM `cache_watches`
                     WHERE `cache_id`=nCacheId
                    ) AS `wu`
                );
            UPDATE `stat_caches` SET `stat_caches`.`watch` = nWatches WHERE `cache_id`=nCacheId;
            IF ROW_COUNT() = 0 THEN
                INSERT IGNORE INTO `stat_caches` (`cache_id`, `watch`) VALUES (nCacheId, nWatches);
            END IF;
        END IF;
     END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-25 18:22:51
